#include <stdio.h>
int main()
{
 float n1,n2,s,d,m,sub;
 printf("Digite o primeiro numero\n");
 scanf("%f",&n1);
 printf("Digite o segundo numero \n");
 scanf("%f",&n2);
 s=n1+n2;
 d=n1/n2;
 m=n1*n2;
 sub=n1-n2;
 printf("Soma=%f\n",s);
 printf("Subtracao=%f\n",sub);
 printf("Divisao=%f\n",d);
 printf("Multi=%f\n",m);
 
}
