#include <stdio.h>
int main()
{
	float zin,co,la;
	printf("KG do latao\n");
    scanf("%f",&la);
	zin=la*0.3;
	co=la*0.7;
	printf("Zinco=%f  Cobre=%f",zin ,co);
}
