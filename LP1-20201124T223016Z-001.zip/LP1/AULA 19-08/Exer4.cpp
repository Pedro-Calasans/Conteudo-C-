#include <stdio.h>
int main()
{
	int m;
	float cm;
	printf("Digite os cm\n");
	scanf("%f",&cm);
	m=(int) cm/100;
	printf("Metros=%d",m);
}
