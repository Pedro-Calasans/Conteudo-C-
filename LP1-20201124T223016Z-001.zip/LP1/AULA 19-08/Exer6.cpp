#include <stdio.h>
int main()
{
 float pr,gar;
 printf("Digite o valor\n");
 scanf("%f",&pr);
 gar=pr*0.10;
 printf("O valor da gorjeta = %f",gar);
 return 0;
}
