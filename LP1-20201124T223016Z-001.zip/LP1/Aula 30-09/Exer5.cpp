#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define TAM 5
int main()
{
	int n[TAM][TAM],i,j,a,b,aux=0;
	srand(time(NULL));
	for(i=0;i<TAM;i++){
		for(j=0;j<TAM;j++){
			n[i][j]=rand()%501; 
		
			for(a=0;a<TAM;a++){
				for(b=0;b<TAM;b++){
					if(n[i][j]> n[a][b]){
						aux=n[i][j];
						n[j][i]=n[a][b];
						n[a][b]=aux;
				          }   
					   }         
		               
			
		
			       }
			       	printf("%d ",n[i][j]);
			}
			
		printf("\n");
	
		}
	

	return 0;
}

