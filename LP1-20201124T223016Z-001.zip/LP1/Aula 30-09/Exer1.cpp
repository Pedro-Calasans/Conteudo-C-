#include <stdio.h>
int main()
{
	int i,j,n1[3][3];
	for(i=0;i<3; i++){
		for(j=0;j<3;j++){
			printf("Numero: \n");
			scanf("%d",&n1[i][j]);
		}
     printf("\n");
	}
	for(i=0;i<3; i++){
		for(j=0;j<3; j++){
		
			printf(" Numero: %d",n1[i][j]);
	}
	printf("\n");
}
return 0;
}
