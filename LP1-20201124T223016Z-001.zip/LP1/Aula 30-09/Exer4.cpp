#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define TAM 20
int main()
{
	int n[TAM][TAM],i,j,ma=0,me=998;
	srand(time(NULL));
	for(i=0;i<TAM;i++){
		for(j=0;j<TAM;j++){
			n[i][j]=rand()%501; 
			printf("   %d",n[i][j]);
			if(n[i][j]<=me) me=n[i][j];
 			if(n[i][j]>=ma) ma=n[i][j];
			}
		printf("\n");	
		
}
	printf("maior= %d  Menor = %d",ma ,me);

	return 0;
}

