#include <stdio.h>
#define TAM 20
int main()
{
	int n[TAM][TAM],i,j;
	for(i=0;i<TAM;i++){
		for(j=0;j<TAM;j++){
			n[i][j]=0;
			if((i==TAM-1) || (j==TAM-1) || (i==0)  || (j==0)  ) n[i][j]=1;
			printf(" %d",n[i][j]);
		}
		printf("\n");
	}
	return 0;
}
