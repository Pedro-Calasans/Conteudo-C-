#include <stdio.h>
#define TAM 20
int main()
{
	int n[TAM][TAM],i,j;
	for(i=0;i<TAM;i++){
		for(j=0;j<TAM;j++){
			n[i][j]=0;
			if((i==j) || (i+j==TAM-1)) n[i][j]=1;
			printf(" %d",n[i][j]);
		}
		printf("\n");
	}
	return 0;
}
