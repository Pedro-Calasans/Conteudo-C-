// .H
#define TAM 5
typedef struct {
	char cargo[40];
	char nivel[40];
	char sexo;
	int idmin;
	int idmax;
	float salario;
	int nvagas;
	
}Vaga;

int menu1();
int menu2(int iniciar);
int idade();
char sexo();
int salario();
int escolaridade();
int buscarvaga();
int preenchevaga(Vaga vetor[TAM]);
void mostravaga(Vaga vetor[TAM]);
int buscarvaga(int a, int b, int c,int d,Vaga arq[TAM],Vaga user);
int novoArq(Vaga vetor[TAM]);
