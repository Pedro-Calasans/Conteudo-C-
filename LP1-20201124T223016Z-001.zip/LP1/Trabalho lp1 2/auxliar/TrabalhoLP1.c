//RASCUNHO
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main()
{
	float salario;
	int menu,iniciar,idade,nivel,res,i,vetor[5];
	char sexo;
	salario=0;
	vetor[0]=5;
	vetor[1]=3;
	vetor[2]=2;
	vetor[3]=1;
	vetor[4]=2;
	idade=0;
	sexo=0;
    comeco:
	printf("Iniciar = 0  \nFinalizar = 1\n");             //INICIO DO PROGRAMA
	scanf("%d",&iniciar);
	system("cls");                          
	while((iniciar!=0) || (iniciar!=1)){            
		printf("Iniciar = 0  \nFinalizar = 1\n");		//LA�O PARA VERIFICAR SE O USARIO ENTROU COM OS VALORES CERTOS ( 0 OU 1)
		scanf("%d",&iniciar);
		system("cls");		
	}
	while(iniciar==0){           //MENU
		printf("  MENU  \n");
		printf("0-Idade\n1-Sexo\n2-Pretensao Salario\n3-Escolaridade\n4-Buscar vagas\n5-Vagas disponiveis\n6-Voltar ao menu anterior\n");
		scanf("%d",&menu);
		system("cls");
	while((menu<0)|| (menu>6)){   //LA�O PARA VERIFICAR SE O USARIO ENTROU COM O VALOR CERTO   ( 0 AT� 6)
		printf("  MENU  \n");
		printf("0-Idade\n1-Sexo\n2-Pretensao Salario\n3-Escolaridade\n4-Buscar vagas\n5-Vagas disponiveis\n6-Voltar ao menu anterior\n");
		scanf("%d",&menu);
		system("cls");            
		}
	switch(menu){     //MENU 2 USANDO SWITCH CASE PARA CADA UMA DAS OP��ES
		case 0:
			printf("Idade:  \n");      //MENU 0 ENTRAR COM A IDADE 
			scanf("%d",&idade);
			system("cls");
			while(idade<16){          //LA�O PARA VERIFICAR SE A IDADE � VALIDA (IDADE>=16)
				printf("Idade invalidade digite novamente\nIdade:  \n");
				scanf("%d",&idade);
				system("cls");				
			}
			break;
		case 1:
			printf("(sexo f ou m)\nSexo: \n");   //MENU 1 ENTRAR COM SEXO 
			scanf(" %c",&sexo);
			system("cls");
			while((sexo!='f') && (sexo!='m')){   // LA�O PARA VERIFCAR SE O SEXO � VALIDO (F= MULHER M= HOMEN)
				printf("Sexo invalido digite novamente\n(sexo f ou m)\nSexo: \n");
				scanf(" %c",&sexo);
				system("cls");
			}
			break;
		case 2:
			printf("Prentesao salario:  \n");  //MENU 2 ENTRAR COM PRETENS�O SALARIAL
			scanf("%f",&salario);
			system("cls");
			while(salario<0){                //LA�O PARA VERIFICAR SE O SALARIO � VALIDO(>0)
				printf("Valor invalido\nPretensao salario:\n");
				scanf("%f",&salario);
				system("cls");
			}
			break;
		case 3:
			printf("Nivel de Escoladirade:\n0=Fundamental Completo\n1=Ensino Medio completo\n2=Superior Completo\n"); //MENU 3 ESCOLARIDADE
			scanf("%d",&nivel);
			system("cls");
			while((nivel>3) && (nivel<0)){     //LA�O PARA VERIFICAR SE A ESCOLIRIDADE � VALIDA (1,2,3)
				printf("Valor invalido");
				printf("Nivel de Escoladirade:\n0=Fundamental Completo\n1=Ensino Medio completo\n2=Superior Completo\n");
				scanf("%d",&nivel);
			}
	
			break;
		case 4:   //MENU 4 PARA VERIFICAR  AS VAGAS DISPONIVEIS
			if((salario==0) && (sexo==0) && (idade==0) && (nivel!=0 || (nivel!=1) || (nivel!=2))){  //  VERIFICAR SE OS DADOS ANTERIORES FORAM INSERIDOS 
				printf("Complete a insercao de dados!!!\n");
				system("pause");
				system("cls");
				}else{
					if((nivel==1)&& (sexo=='f') && (idade>=18) && (salario<=1500) && (vetor[0]>0)){   //VAGA DE RECEPCIONISTA
						printf("VAGA DISPONIVEL:Recepcionista\n");
						printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
						scanf("%d",&res);
						system("cls");
						while((res>1) || (res<0)){          
								printf("Resposta invalida digite novamente\n");  
								printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
								scanf("%d",&res);
								system("cls");
											   	}
								if(res==1){                    //DIMINUIR UMA DAS VAGAS DISPONIVEIS PARA RECEPCIONISTA
									vetor[0]=vetor[0]-1;
									salario=0;  
		                           idade=0;
	    							sexo=0;
										}    			   	
						}else{
							if((nivel==0)&& (sexo=='m') && ((idade>=16) && (idade<=20)) && (salario<=900) && (vetor[1]>0)){ //VERIFICAR VAGA DE AJUDANTE GERAL
								printf("VAGA DISPONIVEL:Ajudante geral\n");
								printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
								scanf("%d",&res);
								system("cls");
								while((res>1) || (res<0)){       
									printf("Resposta invalida digite novamente\n");
									printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
								   	scanf("%d",&res);
								   	system("cls");
													}
									if(res==1){       //DIMINUIR UMA DAS VAGAS DE AJUDANTE GERAL
										vetor[1]=vetor[1]-1;
										salario=0;  
										idade=0;
	    								sexo=0;
										}    				
							}
								else{
									if((nivel==2) && (sexo=='m' || (sexo=='f')) && (idade>=30)  && (salario<=4500) && (vetor[2]>0)){ //VERIFICAR VAGA DE GERENTE DE RH
										printf("VAGA DISPONIVEL:Gerente de RH\n");
										printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
										scanf("%d",&res);
										system("cls");
										while((res>1) || (res<0)){
												printf("Resposta invalida digite novamente\n");
												printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
												scanf("%d",&res);
												system("cls");
													}
												if(res==1){
													vetor[2]=vetor[2]-1;  //DIMINUIR UMA VAGA DE GERENTE DE RH
													}    	
										}else{
											if((nivel==2) && ((sexo=='m') || (sexo=='f')) && (idade>=25)  && (salario<=3500) && (vetor[3]>0)){ //VERIFICAR VAGA DE ANALISTA DE SISTEMAS
												printf("VAGA DISPONIVEL:Analista de Sistemas\n");
												printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
												scanf("%d",&res);
												system("cls");
												while((res>1) || (res<0)){
													printf("Resposta invalida digite novamente\n");
													printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
													scanf("%d",&res);
													system("cls");
													}
												if(res==1){  
													vetor[3]=vetor[3]-1; //DIMINUIR UMA VAGA DE ANALISTA DE SISTEMAS
													salario=0; 
													idade=0;
	    											sexo=0;
													}    	
												}else{
													if((nivel==0)&& ((sexo=='m') || (sexo=='f')) && ((idade>=35) && (idade<=50)) && (salario<=1200) && (vetor[4]>0)){ //VERIFCAR VAGA DE PORTEIRO
													printf("VAGA DISPONIVEL:Porteiro\n");                                                                                                    
													printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
													scanf("%d",&res);
													system("cls");
													while((res>1) || (res<0)){
														printf("Resposta invalida digite novamente\n");
														printf("Deseja aceitar a vaga??(1=sim 0=nao)\n");
														scanf("%d",&res);
														system("cls");
													              }
													if(res==1){
														vetor[4]=vetor[4]-1;  //DIMINUIR UMA VAGA DE PORTEIRO
														salario=0;  
														idade=0;
	    												sexo=0;
													}             
												     }else{ //CASO  OS DADOS DO USUARIO N�O ENCAIXEM EM NENHUMA DAS VAGAS
												     	printf("Infelizmente para o seu perfil nao temos vagas, tente outra vez\n");
												     	getch();
												     	system("cls");
													 }
													}
												}
									}
							}
						
						}
			break;
		case 5: //MENU 5 MOSTRAR VAGAS DISPONIVEIS
			printf("Vagas disponiveis para Recepcionista: %d\n",vetor[0]);
			printf("Vagas disponiveis para Ajudante geral: %d\n",vetor[1]);
			printf("Vagas disponiveis para Gerente de RH: %d\n",vetor[2]);
			printf("Vagas disponiveis para Analista de Sistemas: %d\n",vetor[3]);
			printf("Vagas disponiveis para Porteiro: %d\n",vetor[4]);
			system("pause"); //PRESSIONE QUALQUER TECLA PARA SAIR DO MENU 5
			system("cls"); 
			break;
		case 6:
		 	goto comeco;  //VOLTA PARA O MENU 1 KKK
			}	
	}
}

