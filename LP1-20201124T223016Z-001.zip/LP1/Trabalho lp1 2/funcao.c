   // FUN��O AQUI 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funcao.h"
#define TAM 5
int menu1(){
	int iniciar;
	printf("Iniciar = 0  \nFinalizar = 1\n");             //INICIO DO PROGRAMA
	scanf("%d",&iniciar);
	system("cls");                          
	while((iniciar<0) || (iniciar>1)){            
		printf("Iniciar = 0  \nFinalizar = 1\n");		//LA�O PARA VERIFICAR SE O USARIO ENTROU COM OS VALORES CERTOS ( 0 OU 1)
		scanf("%d",&iniciar);
		system("cls");		
	}
	return iniciar;
}

int menu2(int iniciar){
	int menu;
	         //MENU
		printf("  MENU  \n");
		printf("0-Idade\n1-Sexo\n2-Pretensao Salario\n3-Escolaridade\n4-Buscar vagas\n5-Vagas disponiveis\n6-Voltar ao menu anterior\n");
		scanf("%d",&menu);
		
	while((menu<0)|| (menu>6)){   //LA�O PARA VERIFICAR SE O USARIO ENTROU COM O VALOR CERTO   ( 0 AT� 6)
		printf("  MENU  \n");
		printf("0-Idade\n1-Sexo\n2-Pretensao Salario\n3-Escolaridade\n4-Buscar vagas\n5-Vagas disponiveis\n6-Voltar ao menu anterior\n");
		scanf("%d",&menu);
		            
	}	
   
   return menu;
}

int idade(){
	int idade;
		printf("Idade:  \n");      //MENU 0 ENTRAR COM A IDADE 
			scanf("%d",&idade);
			system("cls");
			while(idade<16){          //LA�O PARA VERIFICAR SE A IDADE � VALIDA (IDADE>=16)
				printf("Idade invalidade digite novamente\nIdade:  \n");
				scanf("%d",&idade);
				system("cls");				
			}
		return idade;	
}

char sexo(){
	char sexo;
	printf("(sexo F ou M)\nSexo: \n");   //MENU 1 ENTRAR COM SEXO 
			scanf(" %c",&sexo);
			system("cls");
			while( (sexo!='F') && (sexo!='M')){   // LA�O PARA VERIFCAR SE O SEXO � VALIDO (F= MULHER M= HOMEN)
				printf("Sexo invalido digite novamente\n(sexo F ou M)\nSexo: \n");
				scanf(" %c",&sexo);
				system("cls");
			}
			return sexo;
}

int salario(){
	    float salario;
		printf("Prentesao salario:  \n");  //MENU 2 ENTRAR COM PRETENS�O SALARIAL
			scanf("%f",&salario);
			system("cls");
			while(salario<0){                //LA�O PARA VERIFICAR SE O SALARIO � VALIDO(>0)
				printf("Valor invalido\nPretensao salario:\n");
				scanf("%f",&salario);
				system("cls");
			}
		return salario;		
}

int escolaridade(){
			int  nivel;
			
			
			printf("Nivel de Escoladirade:\n0=Fundamental Completo\n1=Ensino Medio completo\n2=Superior Completo\n"); //MENU 3 ESCOLARIDADE
			scanf("%d",&nivel);
			system("cls");
			while((nivel>3) && (nivel<0)){     //LA�O PARA VERIFICAR SE A ESCOLIRIDADE � VALIDA (1,2,3)
				printf("Valor invalido");
				printf("Nivel de Escoladirade:\n0=Fundamental Completo\n1=Ensino Medio completo\n2=Superior Completo\n");
				scanf("%d",&nivel);
			}
		return nivel;
			
}

int buscarvaga(int a, int b, int c,int d,Vaga arq[TAM],Vaga user){
	  			    int k,i,posi[TAM],j,z,n;
				  
					 	for(i=0;i<TAM;i++){
					 		if(((user.idmin>=arq[i].idmin) && ((user.idmin<=arq[i].idmax) || (arq[i].idmax==0) )) && ((user.sexo==arq[i].sexo) || (arq[i].sexo=='X')) && (user.salario<=arq[i].salario) && ((strncmp(user.nivel,arq[i].nivel,sizeof(arq[i].nivel))==0) || (n==2)) && (arq[i].nvagas>0) ){
							 
							    printf("\n-----------------------Vaga disponivel----------------------------\n");
							    printf("Cargo:%s\nNivel:%s\nSexo:%c\nIdmin:%d\nIdmax:%d\nSalario:%f\nVagas disponiveis:%d\n\n",arq[i].cargo,arq[i].nivel,arq[i].sexo,arq[i].idmin,arq[i].idmax,arq[i].salario,arq[i].nvagas );
							    printf("\n________________________________________________________________\n");
							    posi[i]=1;
							    z=1;
							    printf("Numero da vaga=%d\n",i);
					        	 }    
							 }
							printf("Deseja aceitar alguma vaga:\n(1= SIM NAO=2)\n");
							printf("Caso nao aparecer nenhuma digite 2:\n");
							
							scanf("%d",&k);
							while((k!=1) && (k!=2)){
								printf("1=SIM E 2=NAO");
								scanf("%d",&k);
							}
							if(k==1){
					     		printf("Numero da vaga:\n");
								scanf("%d",&j);
								while((j>4) || (j<0)){
									printf("Vagas somentes de 0 a 4\n");
									scanf("%d",j);
								}
								while(posi[j]!=1){
									printf("Voce nao pode possuir essa vaga\n");
									scanf("%d",&j);
						              	}
	   		                	arq[j].nvagas=arq[j].nvagas-1;
							          }else{
							          	printf("Certo, seus dados serao zerados\nInsira os dados novamente para procurar outras vagas\n");
							            system("pause");
									  }
							a=0;
							b=0;
							c=0;
							d=0;
                            

  return 0;
}
int preenchevaga(Vaga vetor[TAM]){
	FILE *arq;
	int i, j, k, cont,w=1;
	char aux[25];
	char aux2[15];
	int nint;
	float nfloat;
	
	if((arq = fopen("vagas.txt", "r")) == NULL) return w;
	
	// O c�digo abaixo l� o arquivo linha a linha
	i = 0;
	cont = 0;
	
	// O fgets l� uma linha do arquivo e testa se n�o � retonado NULL, o que significaria que chegou no final do arquivo
	while((fgets(aux, sizeof(aux), arq) != NULL)){

		// Como a linha foi lida em aux com sucesso, � preciso atribuir o conte�do no campo certo da struct
		// A primeira leitura � do "cargo"
		k = 0;
		// O while � para retirar o \n no final da string e colocar o \0 no lugar
     	while(aux[k] != '\n') k++;
		aux[k] = '\0';
		strncpy(vetor[i].cargo, aux, sizeof(vetor[i].cargo));
				
		// Repete o processo anterior para para n�vel de escolaridade 
		fgets(aux, sizeof(aux), arq);
		k = 0;
		while(aux[k] != '\n') k++;
		aux[k] = '\0';
		strncpy(vetor[i].nivel, aux, sizeof(vetor[i].nivel));
				
		// Repete para o sexo
		fgets(aux, sizeof(aux), arq);
		k = 0;
		while(aux[k] != '\n') k++;
		aux[k] = '\0';
		// Como sempre � um char, a atribui��o pode ser direta
		vetor[i].sexo = aux[0];
				
		// Foi lido como string, convertido para inteiro e atribu�do
		// Idade m�nima
		fgets(aux, sizeof(aux), arq);
		k = 0;
		while(aux[k] != '\n') k++;
		aux[k] = '\0';
		vetor[i].idmin = atoi(aux);
				
		// Idem anterior, agora para idade m�xima
		fgets(aux, sizeof(aux), arq);
		k = 0;
		while(aux[k] != '\n') k++;
		aux[k] = '\0';
		vetor[i].idmax = atoi(aux);
				
		// Idem idades, mas agora um float para sal�rio
		fgets(aux, sizeof(aux), arq);
		k = 0;
		while(aux[k] != '\n') k++;
		aux[k] = '\0';
		vetor[i].salario = atof(aux);
				
		// Idem leitura das idades, mas agora para n�mero de vagas para aquele cargo
		fgets(aux, sizeof(aux), arq);
		k = 0;
		while(aux[k] != '\n') k++;
		aux[k] = '\0';
		vetor[i].nvagas = atoi(aux);
					
		// Insere a linha em branco entre os cargos
		printf("\n");
		fgets(aux, sizeof(aux), arq);
		cont++;
		i++;
		
	}
	fclose(arq);
	return 1;	
}

void mostravaga(Vaga vetor[TAM]){
	int i;
	for(i=0;i<TAM;i++){
		  if(vetor[i].nvagas==0) continue;
		printf("Vaga:%s\nNivel:%s\nSexo:%c\nIdade min:%d\nIdade max:%d\nSalario:%f\nVagas disponiveis:%d\n",vetor[i].cargo,vetor[i].nivel,vetor[i].sexo,vetor[i].idmin,vetor[i].idmax,vetor[i].salario,vetor[i].nvagas);
		printf("\n__________________________________________\n");
	}
	system("pause");
}

int novoArq(Vaga vetor[TAM]){
	
	FILE *arquivo;
	int i;
	if((arquivo = fopen("vagas.txt", "w")) == NULL)
	{
		system("cls");
		printf("\nArquivo vazio");
		system("pause");
		return 1;
	}
	for(i = 0; i < TAM; i++)
	{
        if(vetor[i].nvagas==0) continue;
		// Reescrevendo o arquivo com fprintf
												
		fprintf(arquivo, "%s\n", vetor[i].cargo);
		fprintf(arquivo, "%s\n", vetor[i].nivel);
		fprintf(arquivo, "%c\n", vetor[i].sexo);
		fprintf(arquivo, "%d\n", vetor[i].idmin);
		fprintf(arquivo, "%d\n", vetor[i].idmax);
		fprintf(arquivo, "%.2f\n", vetor[i].salario);
		fprintf(arquivo, "%d\n", vetor[i].nvagas);
 		fputs("\n", arquivo);			
	}							
	fclose(arquivo);
	return 0;

}


