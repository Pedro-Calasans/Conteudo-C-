#include <stdio.h>
int main()
{
 float num1=10,num2=5,div;
 div=num1/num2;
 printf("divis�o= %d\n",div);
}
