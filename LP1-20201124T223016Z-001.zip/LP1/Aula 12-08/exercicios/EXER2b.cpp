#include <stdio.h>
int main()
{
  float n1=1.2,n2=2.2,n3=3.2;
  printf("N1= %f\n",n1);	
  printf("N2= %f\n",n2);	
  printf("N3= %f\n",n3);	

}
