#include <stdio.h>
int main()
{
 int num1=10,num2=5,sub;
 sub=num1-num2;
 printf("Subtracao= %d\n",sub);
}
