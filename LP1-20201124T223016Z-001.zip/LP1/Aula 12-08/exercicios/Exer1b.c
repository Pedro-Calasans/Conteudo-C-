#include <stdio.h>
int main()
{
  float n1=1.2,n2=2.2,n3=3.2;
  printf("N1= %f\nN2= %f\nN3= %f\n",n1,n2,n3);	

}
