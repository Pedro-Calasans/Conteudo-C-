#include <stdio.h>
int main()
{
  int n1=1,n2=2,n3=3;
  printf("N1= %d\nN2= %d\nN3=%d\n",n1,n2,n3);	

}
