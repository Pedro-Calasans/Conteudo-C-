#include <stdio.h>
int main()
{
 int num1=10,num2=5,mul;
 mul=num1*num2;
 printf("multiplicacao= %d\n",mul);
}
