#include <stdio.h>

int main()
{
  int num1, num2;
  
  num1 = 5;
  
  num2 = 10;
  
  printf("num 1 = %d, num2 = %d", num1, num2);

  return 0;  
  }
