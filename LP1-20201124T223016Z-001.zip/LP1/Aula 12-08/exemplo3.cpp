#include <stdio.h>

int main()
{
  int num1, num2, soma;
  
  num1 = 10;
  
  num2 = 5;
  soma=num1+num2;
  printf("soma = %d",soma);

  return 0;  
  }
