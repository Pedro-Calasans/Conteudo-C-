#include <stdio.h>

int main()
{
	printf("Ola, mundo");
	
	return 0;
}
