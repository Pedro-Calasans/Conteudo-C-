#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funcao.h"
#define TAM 5
int main(){
	int saida,menu,iniciar,i,a=0,b=0,c=0,d=0,n,posi[TAM],z,k,j,inutil;   
	Vaga user,arq[TAM];
    preenchevaga(arq);  
    system("cls");
    	iniciar=menu1();
    	while(iniciar!=1){		
        menu=menu2(iniciar); 
		system("cls"); 
     	switch(menu){		 
     		case 0:
     			user.idmin=idade();
     			system("cls");
     			a=1;
     		break;
     		case 1:
     			user.sexo=sexo();
     			system("cls");
     			b=1;
     			printf("%c",user.sexo);
     		break;
     		case 2:
     			user.salario=salario();
     			system("cls");
     			c=1;
     		break;
     		case 3:
     			n=escolaridade();
     			if(n==0) strncpy(user.nivel, "Fundamental", sizeof(user.nivel));
     			if(n==1) strncpy(user.nivel, "Medio", sizeof(user.nivel));
     			if(n==2) strncpy(user.nivel, "Superior", sizeof(user.nivel));
     			system("cls");
     			d=1;
     		break;
     		case 4:
     				if((a==0) || (b==0) || (c==0) || (d==0)){
     				printf("Entrada de dados faltando\n");
     				system("pause");     					
					 }else{
					buscarvaga(a,b,c,d,arq,user);					 
					 }
            		a=0;
            		b=0;
            		c=0;
            		d=0;
     		break;
     		case 5:
     			mostravaga(arq);
     			system("cls");
     		break;
     		case 6:
     			iniciar=menu1();
     	break;
          
	}
	 }
novoArq(arq);
return 0;
}
