#include <stdio.h>
int main()
{
	int id,kg;
	printf("Digite a idade\n");
	scanf("%d",&id);
	printf("Digite o peso\n");
	scanf("%d",&kg);
	if ((id<=14)&&(kg<45)){
		printf("Peso leve infantil");
	} 
	if ((id<=14)&&(kg>=45)){
		printf("Peso pesado infantil");
	}
	if ((id>=18)&&(kg>=85)){
		printf("Peso pesado Adulto");
	}
	if ((id>=18)&&(kg<85)){
	    printf("Peso leve Adulto");
	}
	if((id>=15) &&(id<=17)&&(kg<60)){
		printf("Juvenil peso leve");
	}
	if ((id>=15) &&(id<=17)&&(kg>=60)){
		printf("Juvenil peso pesado");
	}
	return 0;
}
	

