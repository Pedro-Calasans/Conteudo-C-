#include <stdio.h>
int main()
{
	float p1,p2,t1,t2,m1,m2,mf;
	printf("Digite p1\n");
	scanf("%f",&p1);
	printf("Digite t1\n");
	scanf("%f",&t1);
	printf("Digite p2\n");
	scanf("%f",&p2);
	printf("Digite t2\n");
	scanf("%f",&t2);
	m1=p1*0.6+t1*0.4;
	m2=p2*0.7+t2*0.3;
	mf=(m1+m2)/2;
	if (mf>=6){
		printf("%f Aluno aprovado",mf);
	}else{
		if (mf>=4){
			printf("%f Aluno de recuperacao",mf);
		}
		else {
			printf("%f Aluno Reprovado",mf);
	}
}
return 0;
}
