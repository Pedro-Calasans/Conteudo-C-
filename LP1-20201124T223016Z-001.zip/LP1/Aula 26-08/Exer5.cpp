#include <stdio.h>
int main()
{
	int n,m;
	printf("Digite o numero\n");
	scanf("%d",&n);
	m=n%2;
	if (m==0) {
		printf("%d = PAR",n);
	}else {
		printf("%d = IMPAR ",n);
	}
	return 0;
}
