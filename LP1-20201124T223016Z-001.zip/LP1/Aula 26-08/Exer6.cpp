#include <stdio.h>
int main()
{
 int ano,m,m1,m2;
 printf("Digite o ano\n");
 scanf("%d",&ano);
 m=ano % 400;
 m1=ano % 4;
 m2=ano % 100;
 if (m==0) {
	printf("O ano %d eh bissexto\n",ano);
  }if ((m1==0)&& (m2!=0)){
  	printf("O ano %d eh bissexto\n",ano);
  }else {
  	printf("O ano %d n eh bissexto\n",ano);
  }
  return 0;
}
