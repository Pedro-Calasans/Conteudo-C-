#include <stdio.h>
int main()
{
	float conta;
	printf("Quanto e 10x5?\n");
	scanf("%f",&conta);
	if (conta!=50){
		printf("Errou burro");
	}
	else {
		printf("parabens acertou e = 50");
	}
	return 0;
}
