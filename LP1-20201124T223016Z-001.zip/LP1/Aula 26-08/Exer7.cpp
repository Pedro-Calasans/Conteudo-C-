#include <stdio.h>
int main()
{
  float n1,n2,n3,n4;
  printf("Digite n1\n");
  scanf("%f",&n1);   
  printf("Digite n2\n");
  scanf("%f",&n2);
  printf("Digite n3\n");
  scanf("%f",&n3);
  printf("Digite n4\n");
  scanf("%f",&n4);
  if (n1>n2){
  	printf("O primeiro quesito esta certo\n");
  }else{
  	printf("O primeiro ta errado\n");
  }
  if (n3>n4){
  	printf("O segundo quesito esta certo\n");
  }else{
  	printf("O segundo quesito esta errado\n");
  }
  if ((n3+n4)<(n1+n2)){
  	printf("O ultimo quesito esta certo\n");
  }else{
  	printf("O ultimo quesito ta errado\n");
  }
}
