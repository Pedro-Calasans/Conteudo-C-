#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct{
	char nome[10];
	char abr[4];
	int dias;
}Meses;
int main(){
	int i,n,j=0;
	Meses a[12];
    a.abr[12]={jan,fev,mar,abr,mai,jun,jul,ago,set,out,nov,dez};
	a.nome[12]={janeiro,fevereiro,abri,maio,junho,julho,agostp,setembro,outubro,novembro,dezembro};
	fgets(a.)
}

