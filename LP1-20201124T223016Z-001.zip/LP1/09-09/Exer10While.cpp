#include <stdio.h>
int main()
{
	int n1,cont;
	n1=1;
	while(n1<250){
		printf("%d\n",n1);
		n1=n1+1;
		cont=cont+1;
		
	
	}
	printf("O numero de numeros para ultrapassar  250 = %d",cont);
	return 0;
}
